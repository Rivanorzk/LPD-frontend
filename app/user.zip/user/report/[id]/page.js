"use client"

import { useEffect, useState } from "react"
import axios from "axios"
import { useParams } from "next/navigation"
import Navbar from "@/components/Navbar"
import {
  MapPin,
  Clock3,
  Heart,
  MessageCircle,
  Share2,
  SendHorizonal,
} from "lucide-react"

export default function ReportDetailPage() {
  const params = useParams()

  const [report, setReport] = useState(null)
  const [comments, setComments] = useState([])
  const [comment, setComment] = useState("")
  const [loading, setLoading] = useState(true)
  const [sending, setSending] = useState(false)
  
  useEffect(() => {
    const fetchDetail = async () => {
      try {
        const token = localStorage.getItem("token")

        const [reportResponse, commentResponse] =
          await Promise.all([
            axios.get(
              `http://localhost:4000/report/${params.id}`,
              {
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              }
            ),

            axios.get(
              `http://localhost:4000/comment/${params.id}`,
              {
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              }
            ),
          ])

        console.log("REPORT:", reportResponse.data)
        console.log("COMMENTS:", commentResponse.data)

        setReport(reportResponse.data)
        setComments(commentResponse.data)
      } catch (error) {
        console.log(error)
      } finally {
        setLoading(false)
      }
    }

    if (params.id) {
      fetchDetail()
    }
  }, [params.id])

  const handleLike = async () => {
  try {
    const token = localStorage.getItem("token")

    const response = await axios.post(
      "http://localhost:4000/like",
      {
        report_id: report.id,
      },
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    )

    const liked = response.data.liked

    setReport((prev) => ({
      ...prev,

      liked_by_user: liked,

      total_likes: liked
        ? Number(prev.total_likes || 0) + 1
        : Number(prev.total_likes || 0) - 1,
    }))
  } catch (error) {
    console.log(error)
  }
}

  const handleComment = async () => {
    if (!comment.trim()) return

    try {
      setSending(true)

      const token = localStorage.getItem("token")

      await axios.post(
        "http://localhost:4000/comment",
        {
          report_id: params.id,
          body: comment,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      const response = await axios.get(
        `http://localhost:4000/comment/${params.id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      setComments(response.data)
      setReport((prev) => ({
        ...prev,
        total_comments:
          Number(prev.total_comments || 0) + 1,
      }))
      setComment("")
    } catch (error) {
      console.log(error)
    } finally {
      setSending(false)
    }
  }

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case " dalam proses":
        return "bg-yellow-100 text-yellow-700"

      case "selesai":
        return "bg-green-100 text-green-700"

      default:
        return "bg-blue-100 text-blue-700"
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen bg-[#F4F7F6]">
        <Navbar />

        <main className="ml-[260px] flex-1 p-10">
          <div className="bg-white h-[600px] rounded-[40px] animate-pulse" />
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-[#F4F7F6]">
      <Navbar />

      <main className="ml-[260px] flex-1 p-10">
        <div className="max-w-5xl mx-auto">
          {/* THREAD CARD */}
          <div className="bg-white rounded-[40px] overflow-hidden shadow-sm border border-slate-100">
            {/* TOP */}
            <div className="p-8 pb-6">
              <div className="flex items-start justify-between gap-5 flex-wrap">
                <div className="flex items-center gap-5">
                  <div className="w-16 h-16 rounded-full bg-[#DFF6F3] overflow-hidden flex items-center justify-center text-3xl">
                    {report?.profile_image ? (
                      <img
                        src={`http://localhost:4000/uploads/${report?.profile_image}`}
                        alt="Profile"
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      "👤"
                    )}
                  </div>

                  <div>
                    <h2 className="text-2xl font-bold text-slate-800">
                      {report?.username}
                    </h2>

                    <div className="flex items-center gap-4 mt-2 text-slate-500 flex-wrap text-sm">
                      <div className="flex items-center gap-2">
                        <Clock3 size={15} />
                        {report?.created_at
                          ? new Date(report.created_at).toLocaleString("id-ID")
                          : "-"}
                      </div>

                      <div className="flex items-center gap-2">
                        <MapPin size={15} />
                        {report?.location}
                      </div>
                    </div>
                  </div>
                </div>

                <div
                  className={`px-5 py-3 rounded-full text-sm font-semibold ${getStatusColor(
                    report?.status
                  )}`}
                >
                  {report?.status || "Menunggu"}
                </div>
              </div>

              {/* CONTENT */}
              <div className="mt-8">
                <div className="flex items-center gap-3 mb-5 flex-wrap">
                  <span className="bg-[#DFF6F3] text-[#004D4D] px-4 py-2 rounded-full text-sm font-semibold">
                    {report?.nama_kategori}
                  </span>
                </div>

                <h1 className="text-4xl font-black text-slate-800 leading-tight mb-5">
                  {report?.header}
                </h1>

                <p className="text-slate-600 leading-relaxed text-lg whitespace-pre-line">
                  {report?.body}
                </p>
              </div>
            </div>

            {/* IMAGE */}
            {report?.image && (
              <div className="px-8 pb-8">
                <img
                  src={`http://localhost:4000/uploads/${report?.image}`}
                  alt={report.header}
                  className="w-full h-[550px] object-cover rounded-[32px] border border-slate-100"
                />
              </div>
            )}

            {/* ACTIONS */}
            <div className="border-t border-slate-100 px-8 py-6 flex items-center justify-between flex-wrap gap-5">
              <div className="flex items-center gap-8 text-slate-500">
                <button 
                  className={`flex items-center gap-2 transition ${
                    report?.liked_by_user
                      ? "text-red-500"
                      : "text-slate-500 hover:text-red-500"
                  }`}
                  onClick={handleLike}
                >
                  <Heart size={22} 
                    fill={report?.liked_by_user ? "currentColor" : "none"}
                  />
                  <span>{report.total_likes || 0} Likes</span>
                </button>

                <button className="flex items-center gap-2 hover:text-teal-700 transition">
                  <MessageCircle size={22} />
                  <span>{report?.total_comments || 0} Komentar</span>
                </button>

                <button className="flex items-center gap-2 hover:text-blue-600 transition">
                  <Share2 size={22} />
                  <span>Bagikan</span>
                </button>
              </div>
            </div>
          </div>

          {/* COMMENT SECTION */}
          <div className="bg-white rounded-[40px] shadow-sm border border-slate-100 mt-10 p-8">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-slate-800">
                  Diskusi Warga
                </h2>

                <p className="text-slate-500 mt-2">
                  Komentar dan dukungan masyarakat sekitar
                </p>
              </div>

              <div className="bg-[#DFF6F3] text-[#004D4D] px-5 py-3 rounded-2xl font-semibold">
                {comments.length} Komentar
              </div>
            </div>

            {/* INPUT */}
            <div className="bg-[#F8FAFA] border border-slate-100 rounded-[32px] p-6 mb-10">
              <textarea
                rows="4"
                placeholder="Tulis komentar atau dukungan Anda..."
                value={comment}
                onChange={(e) =>
                  setComment(e.target.value)
                }
                className="w-full bg-transparent outline-none resize-none text-slate-700 placeholder:text-slate-400"
              />

              <div className="flex justify-end mt-5">
                <button
                  onClick={handleComment}
                  disabled={sending}
                  className="bg-[#004D4D] hover:bg-[#006666] text-white px-6 py-4 rounded-2xl font-semibold transition flex items-center gap-2 disabled:opacity-50"
                >
                  <SendHorizonal size={18} />
                  {sending
                    ? "Mengirim..."
                    : "Kirim Komentar"}
                </button>
              </div>
            </div>

            {/* COMMENTS */}
            <div className="space-y-6">
              {comments.length === 0 ? (
                <div className="text-center py-16">
                  <div className="text-7xl mb-4">
                    💬
                  </div>

                  <h3 className="text-2xl font-bold text-slate-700">
                    Belum Ada Komentar
                  </h3>

                  <p className="text-slate-500 mt-3">
                    Jadilah orang pertama yang berdiskusi.
                  </p>
                </div>
              ) : (
                comments.map((item) => (
                  <div
                    key={item.id}
                    className="bg-[#F8FAFA] border border-slate-100 rounded-[32px] p-6"
                  >
                    <div className="flex items-start gap-5">
                      <div className="w-14 h-14 rounded-full bg-[#DFF6F3] overflow-hidden flex items-center justify-center text-2xl shrink-0">
                        {item?.image ? (
                          <img
                            src={`http://localhost:4000/uploads/${item?.image}`}
                            alt="Profile"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          "👤"
                        )}
                      </div>

                      <div className="flex-1">
                        <div className="flex items-center justify-between gap-5 flex-wrap">
                          <div>
                            <h3 className="font-bold text-lg text-slate-800">
                              {item.username}
                            </h3>

                            <p className="text-sm text-slate-500 mt-1">
                              {item?.created_at
                                ? new Date(
                                    item?.created_at
                                  ).toLocaleString("id-ID")
                                : "-"}
                            </p>
                          </div>
                        </div>

                        <p className="text-slate-700 leading-relaxed mt-5 whitespace-pre-line">
                          {item.body}
                        </p>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
