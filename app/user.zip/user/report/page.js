"use client"

import { useEffect, useState } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import dynamic from "next/dynamic"
import axios from "axios"
import Navbar from "@/components/Navbar"

const LocationPicker = dynamic(
  () => import("@/components/LocationPicker"),
  {
    ssr: false,
  }
)

export default function CreateReportPage() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const categoryId = searchParams.get("category")
  const [categories, setCategories] = useState([])
  const [preview, setPreview] = useState(null)
  const [loading, setLoading] = useState(false)
  const [position, setPosition] = useState(null)

  const initialCategory = searchParams.get("category") || ""

  const [formData, setFormData] = useState({
    header: "",
    body: "",
    category_id: initialCategory,
    location: "",
    latitude: "",
    longitude: "",
    image: null,
  })


 useEffect(() => {
  const loadCategories = async () => {
    try {
      const response = await axios.get(
        "http://localhost:4000/categories"
      )

      setCategories(response.data)
    } catch (error) {
      console.log(error)
    }
  }

  loadCategories()
}, [])


  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    })
  }

  const handleImage = (e) => {
    const file = e.target.files[0]

    setFormData({
      ...formData,
      image: file,
    })

    if (file) {
      setPreview(URL.createObjectURL(file))
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault()

    try {
      setLoading(true)

      const token = localStorage.getItem("token")

      const payload = new FormData()

      payload.append("header", formData.header)
      payload.append("body", formData.body)
      payload.append("category_id", formData.category_id)
      payload.append("location", formData.location)
      payload.append("latitude", formData.latitude)
      payload.append("longitude", formData.longitude)
      payload.append("image", formData.image)

      await axios.post(
        "http://localhost:4000/report",
        payload,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      )

      alert("Laporan berhasil dibuat")

      router.push("/user/dashboard")
    } catch (error) {
      console.log(error)
      alert("Gagal membuat laporan")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen bg-[#F4F7F6]">
      <Navbar />

      <main className="ml-[260px] flex-1 p-10">
        {/* HEADER */}
        <div className="mb-10">
          <h1 className="text-4xl font-bold text-slate-800">
            Buat Laporan Baru
          </h1>

          <p className="text-slate-500 mt-3 text-lg">
            Laporkan masalah di sekitar Anda untuk membantu kota menjadi lebih baik.
          </p>
        </div>

        {/* FORM */}
        <div className="bg-white rounded-[32px] shadow-sm border border-slate-100 p-10 max-w-5xl">
          <form onSubmit={handleSubmit} className="space-y-8">
            {/* JUDUL */}
            <div>
              <label className="block mb-3 text-lg font-semibold text-slate-700">
                Judul Laporan
              </label>

              <input
                type="text"
                name="header"
                placeholder="Contoh: Jalan Berlubang di Margonda"
                value={formData.header}
                onChange={handleChange}
                className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#004D4D] bg-slate-50"
                required
              />
            </div>

            {/* KATEGORI */}
            <div>
              <label className="block mb-3 text-lg font-semibold text-slate-700">
                Kategori Laporan
              </label>

              <select
                name="category_id"
                value={formData.category_id}
                onChange={handleChange}
                className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#004D4D] bg-slate-50"
                required
              >
                <option value="">
                  Pilih kategori laporan
                </option>

                {categories.map((category) => (
                  <option
                    key={category.id}
                    value={category.id}
                  >
                    {category.nama_kategori}
                  </option>
                ))}
              </select>
            </div>

            {/* LOKASI */}
            <div>
              <label className="block mb-3 text-lg font-semibold text-slate-700">
                Lokasi
              </label>

              <input
                type="text"
                name="location"
                placeholder="Contoh: Jl. Margonda Raya, Depok"
                value={formData.location}
                onChange={handleChange}
                className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#004D4D] bg-slate-50"
                required
              />
              <div>
                <label className="block mb-3 text-lg font-semibold">
                  Pilih Lokasi di Peta
                </label>

                <LocationPicker
                  setPosition={async (latlng) => {
                    setPosition(latlng)

                    try {
                      const response = await axios.get(
                        "http://localhost:4000/location/reverse",
                        {
                          params: {
                            lat: latlng.lat,
                            lon: latlng.lng,
                          },
                        }
                      )
                      const address =
                        response.data.display_name

                      setFormData((prev) => ({
                        ...prev,
                        location: address,
                        latitude: latlng.lat,
                        longitude: latlng.lng,
                      }))
                    } catch (error) {
                      console.log(error)

                      setFormData((prev) => ({
                        ...prev,
                        location: `${latlng.lat}, ${latlng.lng}`,
                        latitude: latlng.lat,
                        longitude: latlng.lng,
                      }))
                    }
                  }}
                />
              </div>
            </div>

            {/* DESKRIPSI */}
            <div>
              <label className="block mb-3 text-lg font-semibold text-slate-700">
                Isi Laporan
              </label>

              <textarea
                name="body"
                rows="7"
                placeholder="Jelaskan detail masalah yang ingin dilaporkan..."
                value={formData.body}
                onChange={handleChange}
                className="w-full px-5 py-4 rounded-2xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-[#004D4D] bg-slate-50 resize-none"
                required
              />
            </div>

            {/* IMAGE */}
            <div>
              <label className="block mb-3 text-lg font-semibold text-slate-700">
                Upload Foto
              </label>

              <label className="border-2 border-dashed border-slate-300 rounded-3xl p-10 flex flex-col items-center justify-center text-center bg-slate-50 hover:bg-slate-100 transition cursor-pointer">
                <div className="text-5xl mb-4">📸</div>

                <p className="font-semibold text-slate-700 text-lg">
                  Klik untuk upload foto laporan
                </p>

                <p className="text-slate-500 mt-2 text-sm">
                  PNG, JPG, JPEG
                </p>

                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImage}
                  className="hidden"
                />
              </label>

              {preview && (
                <div className="mt-6">
                  <img
                    src={preview}
                    alt="Preview"
                    className="w-full max-w-xl h-[300px] object-cover rounded-3xl shadow-sm"
                  />
                </div>
              )}
            </div>

            {/* PREVIEW THREAD */}
            <div className="bg-[#F8FAFA] rounded-3xl p-8 border border-slate-200">
              <h2 className="text-2xl font-bold mb-6 text-slate-800">
                Preview Thread Laporan
              </h2>

              <div className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100">
                <div className="flex items-center gap-4 mb-5">
                  <div className="w-14 h-14 rounded-full bg-[#DFF6F3] flex items-center justify-center text-2xl">
                    👤
                  </div>

                  <div>
                    <h3 className="font-bold text-lg">
                      Anda
                    </h3>

                    <p className="text-sm text-slate-500">
                      Baru saja • {formData.location || "Lokasi belum diisi"}
                    </p>
                  </div>
                </div>

                <h2 className="text-2xl font-bold text-slate-800 mb-3">
                  {formData.header || "Judul laporan Anda"}
                </h2>

                <p className="text-slate-600 leading-relaxed mb-5">
                  {formData.body ||
                    "Isi laporan akan tampil di sini sebagai thread publik."}
                </p>

                {preview && (
                  <img
                    src={preview}
                    alt="Preview"
                    className="w-full h-[350px] object-cover rounded-3xl mb-5"
                  />
                )}

                <div className="flex items-center gap-6 text-slate-500 border-t pt-5">
                  <button type="button" className="hover:text-teal-700 transition">
                    👍 0 Dukungan
                  </button>

                  <button type="button" className="hover:text-teal-700 transition">
                    💬 0 Komentar
                  </button>

                  <button type="button" className="hover:text-teal-700 transition">
                    🔗 Bagikan
                  </button>
                </div>
              </div>
            </div>

            {/* BUTTON */}
            <div className="flex items-center justify-end gap-4 pt-4">
              <button
                type="button"
                onClick={() => router.back()}
                className="px-6 py-4 rounded-2xl border border-slate-300 text-slate-700 font-semibold hover:bg-slate-100 transition"
              >
                Batal
              </button>

              <button
                type="submit"
                disabled={loading}
                className="bg-[#004D4D] hover:bg-[#006666] text-white px-8 py-4 rounded-2xl font-semibold transition shadow-lg disabled:opacity-50"
              >
                {loading ? "Mengirim..." : "Kirim Laporan"}
              </button>
            </div>
          </form>
        </div>
      </main>
    </div>
  )
}
