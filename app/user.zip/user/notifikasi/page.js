"use client"

import { useEffect, useState } from "react"
import axios from "axios"
import Navbar from "@/components/Navbar"

import {
  Bell,
  CheckCircle2,
  Clock3,
  MessageCircle,
  Heart,
  AlertCircle,
} from "lucide-react"

export default function NotificationPage() {
  const [notifications, setNotifications] =
    useState([])

  const [loading, setLoading] =
    useState(true)

  useEffect(() => {
    const fetchNotifications =
      async () => {
        try {
          const token =
            localStorage.getItem("token")

          // ambil semua laporan
          const reportResponse =
            await axios.get(
              "http://localhost:4000/report",
              {
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              }
            )

          // ambil user login
          const userResponse =
            await axios.get(
              "http://localhost:4000/users/me",
              {
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              }
            )

          // filter laporan user login saja
          const userReports =
            reportResponse.data.filter(
              (item) =>
                item.user_id ===
                userResponse.data.id
            )

          const notifData =
            userReports.map((item) => ({
              id: item.id,
              title: item.header,
              status: item.status,
              likes:
                item.total_likes || 0,
              comments:
                item.total_comments || 0,
              created_at:
                item.created_at,
            }))

          setNotifications(notifData)
        } catch (error) {
          console.log(error)
        } finally {
          setLoading(false)
        }
      }

    fetchNotifications()
  }, [])

  const getIcon = (status) => {
    switch (status?.toLowerCase()) {
      case "selesai":
        return (
          <CheckCircle2 className="text-green-600" />
        )

      case "diproses":
        return (
          <Clock3 className="text-yellow-600" />
        )

      default:
        return (
          <AlertCircle className="text-blue-600" />
        )
    }
  }

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case "selesai":
        return "bg-green-100 text-green-700"

      case "diproses":
        return "bg-yellow-100 text-yellow-700"

      default:
        return "bg-blue-100 text-blue-700"
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen bg-[#F4F7F6]">
        <Navbar />

        <main className="ml-[260px] flex-1 p-10">
          <div className="bg-white h-[400px] rounded-[40px] animate-pulse" />
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-[#F4F7F6]">
      <Navbar />

      <main className="ml-[260px] flex-1 p-10">
        <div className="max-w-5xl mx-auto">
          {/* HEADER */}
          <div className="bg-gradient-to-r from-[#004D4D] to-[#006666] rounded-[32px] p-10 text-white shadow-lg">
            <h1 className="text-5xl font-black">
              Notifikasi Saya
            </h1>

            <p className="mt-4 text-white/80 text-lg">
              Update terbaru dari laporan
              yang Anda buat.
            </p>
          </div>

          {/* LIST */}
          <div className="mt-10 space-y-5">
            {notifications.length ===
            0 ? (
              <div className="bg-white rounded-[32px] p-16 text-center shadow-sm border border-slate-100">
                <div className="text-7xl mb-5">
                  🔔
                </div>

                <h2 className="text-3xl font-black text-slate-800">
                  Belum Ada Notifikasi
                </h2>

                <p className="text-slate-500 mt-4">
                  Semua update laporan Anda
                  akan muncul di sini.
                </p>
              </div>
            ) : (
              notifications.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-[32px] p-7 shadow-sm border border-slate-100 hover:shadow-lg transition"
                >
                  <div className="flex items-start gap-5">
                    <div className="w-14 h-14 rounded-full bg-[#DFF6F3] flex items-center justify-center shrink-0">
                      {getIcon(item.status)}
                    </div>

                    <div className="flex-1">
                      <div className="flex items-start justify-between gap-5 flex-wrap">
                        <div>
                          <h2 className="text-xl font-bold text-slate-800">
                            {item.title}
                          </h2>

                          <p className="text-slate-500 mt-2">
                            Status laporan:
                            <span
                              className={`ml-2 px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(
                                item.status
                              )}`}
                            >
                              {item.status ||
                                "Menunggu"}
                            </span>
                          </p>
                        </div>

                        <span className="text-sm text-slate-400">
                          {new Date(
                            item.created_at
                          ).toLocaleDateString(
                            "id-ID"
                          )}
                        </span>
                      </div>

                      <div className="flex items-center gap-6 mt-5 text-sm text-slate-500 flex-wrap">
                        <div className="flex items-center gap-2">
                          <Heart size={16} />
                          {item.likes} Likes
                        </div>

                        <div className="flex items-center gap-2">
                          <MessageCircle size={16} />
                          {item.comments} Komentar
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  )
}