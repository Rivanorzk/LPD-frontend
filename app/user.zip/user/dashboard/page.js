"use client"

import { useEffect, useState } from "react"
import axios from "axios"
import Navbar from "@/components/Navbar"
import { useRouter } from "next/navigation"
import ReportThread from "@/components/ReportThread"
import {
  FileText,
  Building2,
  HeartPulse,
  ShieldCheck,
  Users
} from "lucide-react";

export default function DashboardPage() {
  const router = useRouter()
  const [categories, setCategories] = useState([])
  const [user, setUser] = useState(null)
  const [reports, setReports] = useState([])
  const [loading, setLoading] = useState(true)
  
  const fetchCategories = async () => {
    try {
      const response = await axios.get(
        "http://localhost:4000/categories"
      )

      setCategories(response.data)
    } catch (error) {
      console.log(error)
    }
  }

  const categoryIcons = {
  "pelayanan publik & administrasi": FileText,
  "infrastruktur dan lingkungan hidup": Building2,
  "kesejahteraan sosial dan kesehatan": HeartPulse,
  "keamanan dan ketertiban umum": ShieldCheck,
  "kepegawaian dan integritas": Users,
}

  const fetchReports = async () => {
  try {
    const token = localStorage.getItem("token")

    const response = await axios.get(
      "http://localhost:4000/report",
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    )

    setReports(response.data)
  } catch (error) {
    console.log(error)
  } finally {
    setLoading(false)
  }
}

  const fetchUser = async () => {
  try {
    const token = localStorage.getItem("token")

    console.log("TOKEN:", token)

    const response = await axios.get(
      "http://localhost:4000/users/me",
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    )

    console.log("USER RESPONSE:", response.data)

    setUser(response.data)
  } catch (error) {
    console.log("ERROR USER:", error)
  }
}

  useEffect(() => {
    const fetchData = async () => {
      await Promise.all([
        fetchCategories(),
        fetchReports(),
        fetchUser(),
      ])
    }

    fetchData()
  }, [])

  return (
    <div className="flex min-h-screen bg-[#F4F7F6]">
      <Navbar />

      <main className="ml-[260px] flex-1 p-8">
        {/* HEADER */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <h1 className="text-4xl font-bold text-slate-800">
              Halo, {user?.username}!
            </h1>

            <p className="text-slate-500 mt-2">
              Apa yang ingin Anda laporkan hari ini?
            </p>
          </div>

          <div className="flex items-center gap-4">
            <input
              type="text"
              placeholder="Cari laporan..."
              className="px-5 py-4 rounded-2xl border border-slate-200 bg-white w-[350px]"
            />

            <button onClick={() => router.push("/user/report")} 
            className="bg-[#004D4D] text-white px-6 py-4 rounded-2xl font-semibold hover:bg-[#006666] transition">
              + Buat Laporan
            </button>
          </div>
        </div>

        {/* STATS */}
        <div className="grid grid-cols-5 gap-5 mb-10">
          <div className="bg-white rounded-3xl p-6 shadow-sm">
            <p className="text-slate-500">Total Laporan</p>
            <h2 className="text-4xl font-bold mt-2">
              {reports.length}
            </h2>
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-sm">
            <p className="text-slate-500">Menunggu</p>
            <h2 className="text-4xl font-bold mt-2 text-gray-500">
              {
                reports.filter(
                  (r) => r.status === "Menunggu"
                ).length
              }
            </h2>
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-sm">
            <p className="text-slate-500">Diproses</p>
            <h2 className="text-4xl font-bold mt-2 text-yellow-500">
              {
                reports.filter(
                  (r) => r.status === "Dalam Proses"
                ).length
              }
            </h2>
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-sm">
            <p className="text-slate-500">Selesai</p>
            <h2 className="text-4xl font-bold mt-2 text-green-600">
              {
                reports.filter(
                  (r) => r.status === "Selesai"
                ).length
              }
            </h2>
          </div>

          <div className="bg-white rounded-3xl p-6 shadow-sm">
            <p className="text-slate-500">Ditolak</p>
            <h2 className="text-4xl font-bold mt-2 text-red-600">
              {
                reports.filter(
                  (r) => r.status === "Ditolak"
                ).length
              }
            </h2>
          </div>
        </div>

        {/* CATEGORY */}
        <section className="mb-14">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-3xl font-bold">
              Kategori Laporan
            </h2>

            <button className="text-teal-700 font-medium">
              Lihat Semua
            </button>
          </div>

          <div className="grid grid-cols-5 gap-5">
            {categories.map((item) => {
              const Icon =
                categoryIcons[item.nama_kategori] || FileText

              return (
                <div
                  key={item.id}
                  onClick={() =>
                    router.push(
                      `/user/report?category=${item.id}`
                    )
                  }
                  className="bg-white rounded-3xl p-6 cursor-pointer hover:shadow-xl transition hover:-translate-y-1"
                >
                  <div className="w-16 h-16 rounded-2xl bg-[#DFF6F3] mb-5 flex items-center justify-center">
                    <Icon
                      size={30}
                      className="text-[#004D4D]"
                    />
                  </div>

                  <h3 className="font-semibold text-lg leading-snug">
                    {item.nama_kategori}
                  </h3>

                  <p className="text-slate-500 mt-2 text-sm">
                    Laporan aktif
                  </p>
                </div>
              )
            })}
          </div>
        </section>

        {/* CIVIC THREAD FEED */}
        <section>
          <div className="flex justify-between items-center mb-8">
            <div>
              <h2 className="text-3xl font-bold">
                Laporan Terbaru
              </h2>

              <p className="text-slate-500 mt-2">
                Laporan dan diskusi warga sekitar
              </p>
            </div>

            <button className="text-teal-700 font-medium">
              Lihat Semua
            </button>
          </div>

          <ReportThread />
        </section>
      </main>
    </div>
  )
}