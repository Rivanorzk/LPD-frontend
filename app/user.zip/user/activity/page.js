"use client"

import { useEffect, useState } from "react"
import axios from "axios"
import Navbar from "@/components/Navbar"

import {
  FileText,
  Heart,
  MessageCircle,
  Clock3,
  CheckCircle2,
  AlertCircle,
} from "lucide-react"

export default function ActivityPage() {
  const [activities, setActivities] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchActivities = async () => {
      try {
        const token = localStorage.getItem("token")

        const reportResponse = await axios.get(
          "http://localhost:4000/report",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        )

        const userResponse = await axios.get(
          "http://localhost:4000/users/me",
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        )

        const userReports =
          reportResponse.data.filter(
            (item) =>
              item.user_id ===
              userResponse.data.id
          )

        setActivities(userReports)
      } catch (error) {
        console.log(error)
      } finally {
        setLoading(false)
      }
    }

    fetchActivities()
  }, [])

  const getStatusIcon = (status) => {
    switch (status?.toLowerCase()) {
      case "selesai":
        return (
          <CheckCircle2 className="text-green-600" />
        )

      case "diproses":
        return (
          <Clock3 className="text-yellow-600" />
        )

      default:
        return (
          <AlertCircle className="text-blue-600" />
        )
    }
  }

  const getStatusColor = (status) => {
    switch (status?.toLowerCase()) {
      case "selesai":
        return "bg-green-100 text-green-700"

      case "diproses":
        return "bg-yellow-100 text-yellow-700"

      default:
        return "bg-blue-100 text-blue-700"
    }
  }

  if (loading) {
    return (
      <div className="flex min-h-screen bg-[#F4F7F6]">
        <Navbar />

        <main className="ml-[260px] flex-1 p-10">
          <div className="bg-white h-[500px] rounded-[40px] animate-pulse" />
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-[#F4F7F6]">
      <Navbar />

      <main className="ml-[260px] flex-1 p-10">
        <div className="max-w-6xl mx-auto">
          {/* HEADER */}
          <div className="bg-gradient-to-r from-[#004D4D] to-[#006666] rounded-[32px] p-10 text-white shadow-lg">
            <h1 className="text-5xl font-black">
              Aktivitas Saya
            </h1>

            <p className="mt-4 text-white/80 text-lg">
              Riwayat aktivitas dan laporan Anda.
            </p>
          </div>

          {/* STATS */}
          <div className="grid grid-cols-4 gap-6 mt-10">
            <div className="bg-white rounded-[28px] p-6 shadow-sm border border-slate-100">
              <div className="flex items-center gap-3 text-[#004D4D]">
                <FileText />
                <span className="font-semibold">
                  Total Laporan
                </span>
              </div>

              <h2 className="text-4xl font-black text-slate-800 mt-5">
                {activities.length}
              </h2>
            </div>

            <div className="bg-white rounded-[28px] p-6 shadow-sm border border-slate-100">
              <div className="flex items-center gap-3 text-red-500">
                <Heart />
                <span className="font-semibold">
                  Total Likes
                </span>
              </div>

              <h2 className="text-4xl font-black text-slate-800 mt-5">
                {activities.reduce(
                  (acc, item) =>
                    acc +
                    Number(item.total_likes || 0),
                  0
                )}
              </h2>
            </div>

            <div className="bg-white rounded-[28px] p-6 shadow-sm border border-slate-100">
              <div className="flex items-center gap-3 text-teal-600">
                <MessageCircle />
                <span className="font-semibold">
                  Komentar
                </span>
              </div>

              <h2 className="text-4xl font-black text-slate-800 mt-5">
                {activities.reduce(
                  (acc, item) =>
                    acc +
                    Number(
                      item.total_comments || 0
                    ),
                  0
                )}
              </h2>
            </div>

            <div className="bg-white rounded-[28px] p-6 shadow-sm border border-slate-100">
              <div className="flex items-center gap-3 text-yellow-600">
                <Clock3 />
                <span className="font-semibold">
                  Diproses
                </span>
              </div>

              <h2 className="text-4xl font-black text-slate-800 mt-5">
                {
                  activities.filter(
                    (item) =>
                      item.status?.toLowerCase() ===
                      "diproses"
                  ).length
                }
              </h2>
            </div>
          </div>

          {/* TIMELINE */}
          <div className="mt-10 space-y-6">
            {activities.map((item) => (
              <div
                key={item.id}
                className="bg-white rounded-[32px] p-8 shadow-sm border border-slate-100"
              >
                <div className="flex items-start justify-between gap-6 flex-wrap">
                  <div className="flex gap-5">
                    <div className="w-16 h-16 rounded-full bg-[#DFF6F3] flex items-center justify-center shrink-0">
                      {getStatusIcon(item.status)}
                    </div>

                    <div>
                      <h2 className="text-2xl font-bold text-slate-800">
                        {item.header}
                      </h2>

                      <p className="text-slate-500 mt-3 leading-relaxed">
                        {item.body?.slice(0, 120)}
                        ...
                      </p>

                      <div className="flex items-center gap-5 mt-5 flex-wrap text-sm text-slate-500">
                        <span>
                          📍 {item.location}
                        </span>

                        <span>
                          ❤️{" "}
                          {item.total_likes || 0}{" "}
                          Likes
                        </span>

                        <span>
                          💬{" "}
                          {item.total_comments ||
                            0}{" "}
                          Komentar
                        </span>

                        <span>
                          🕒{" "}
                          {new Date(
                            item.created_at
                          ).toLocaleDateString(
                            "id-ID"
                          )}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div
                    className={`px-5 py-3 rounded-full font-semibold ${getStatusColor(
                      item.status
                    )}`}
                  >
                    {item.status || "Menunggu"}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </main>
    </div>
  )
}