"use client"

import { useEffect, useState } from "react"
import axios from "axios"
import Navbar from "@/components/Navbar"
import {
  User,
  ShieldCheck,
  MapPin,
  Calendar,
  FileText,
  CheckCircle2,
  Clock3,
} from "lucide-react"

import { useRouter } from "next/navigation"

export default function ProfilePage() {
  const [user, setUser] = useState(null)
  const [reports, setReports] = useState([])
  const [loading, setLoading] = useState(true)
  const [previewImage, setPreviewImage] = useState(null)
  const [uploading, setUploading] = useState(false)
  const router = useRouter()

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const token = localStorage.getItem("token")

        const [userResponse, reportResponse] =
          await Promise.all([
            axios.get(
              "http://localhost:4000/users/me",
              {
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              }
            ),

            axios.get(
              "http://localhost:4000/report",
              {
                headers: {
                  Authorization: `Bearer ${token}`,
                },
              }
            ),
          ])

        setUser(userResponse.data)

        const userReports =
          reportResponse.data.filter(
            (report) =>
              report.user_id ===
              userResponse.data.id
          )

        setReports(userReports)
      } catch (error) {
        console.log(error)
      } finally {
        setLoading(false)
      }
    }

    fetchProfile()
  }, [])

  const handleProfileImage = async (e) => {
    const file = e.target.files[0]

    if (!file) return

    try {
      setUploading(true)

      const token = localStorage.getItem("token")

      const formData = new FormData()
      formData.append("image", file)

      const response = await axios.put(
        "http://localhost:4000/users/profile-image",
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "multipart/form-data",
          },
        }
      )

      setPreviewImage(
        `http://localhost:4000/uploads/${response.data.image}?t=${Date.now()}`
      )

      setUser((prev) => ({
        ...prev,
        image: response.data.image,
      }))
    } catch (error) {
      console.log(error)
      alert("Gagal upload foto profile")
    } finally {
      setUploading(false)
    }
  }

  const totalReports = reports.length

  const completedReports = reports.filter(
    (r) =>
      r.status?.toLowerCase() ===
      "Selesai"
  ).length

  const processedReports = reports.filter(
    (r) =>
      r.status?.toLowerCase() ===
      "Dalam Proses"
  ).length

  if (loading) {
    return (
      <div className="flex min-h-screen bg-[#F4F7F6]">
        <Navbar />

        <main className="ml-[260px] flex-1 p-10">
          <div className="animate-pulse bg-white h-[300px] rounded-3xl" />
        </main>
      </div>
    )
  }

  return (
    <div className="flex min-h-screen bg-[#F4F7F6]">
      <Navbar />

      <main className="ml-[260px] flex-1 p-10">
        {/* HEADER */}
        <div className="bg-gradient-to-r from-[#004D4D] to-[#006666] rounded-[24px] p-10 text-white shadow-xl overflow-hidden relative">
          <div className="absolute top-0 right-0 opacity-10 text-[250px] font-black">
            LDP
          </div>

          <div className="relative z-10 flex items-center justify-between flex-wrap gap-10">
            <div className="flex items-center gap-8">
              <div className="relative">
                <div className="w-32 h-32 rounded-full bg-white/20 backdrop-blur-md border border-white/20 overflow-hidden shadow-lg">
                  {previewImage || user?.image ? (
                    <img
                      src={
                        previewImage ||
                        `http://localhost:4000/uploads/${user?.image}`
                      }
                      alt="Profile"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-6xl">
                      👤
                    </div>
                  )}
                </div>

                <label className="absolute bottom-0 right-0 bg-white text-slate-700 w-11 h-11 rounded-full flex items-center justify-center shadow-lg cursor-pointer hover:scale-105 transition">
                  📷

                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleProfileImage}
                  />
                </label>
              </div>

              <div>
                <h1 className="text-5xl font-black">
                  {user?.username}
                </h1>

                <div className="flex items-center gap-3 mt-4 flex-wrap">
                  <div className="bg-white/15 px-4 py-2 rounded-full flex items-center gap-2 text-sm">
                    <ShieldCheck size={16} />
                    {user?.role}
                  </div>

                  <div className="bg-white/15 px-4 py-2 rounded-full flex items-center gap-2 text-sm">
                    <Calendar size={16} />
                    Warga Aktif
                  </div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-5">
              <div className="bg-white/10 backdrop-blur-md rounded-3xl p-6 min-w-[160px] border border-white/10">
                <p className="text-white/70 text-sm">
                  Total Laporan
                </p>

                <h2 className="text-4xl font-black mt-2">
                  {totalReports}
                </h2>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-3xl p-6 min-w-[160px] border border-white/10">
                <p className="text-white/70 text-sm">
                  Diproses
                </p>

                <h2 className="text-4xl font-black mt-2 text-yellow-300">
                  {processedReports}
                </h2>
              </div>

              <div className="bg-white/10 backdrop-blur-md rounded-3xl p-6 min-w-[160px] border border-white/10">
                <p className="text-white/70 text-sm">
                  Selesai
                </p>

                <h2 className="text-4xl font-black mt-2 text-green-300">
                  {completedReports}
                </h2>
              </div>
            </div>
          </div>
        </div>

        {/* PROFILE INFO */}
        <div className="grid grid-cols-3 gap-8 mt-10">
          {/* LEFT */}
          <div className="space-y-8">
            <div className="bg-white rounded-md p-8 shadow-sm border border-slate-100">
              <h2 className="text-2xl font-bold mb-6 text-slate-800">
                Informasi Akun
              </h2>

              <div className="space-y-5">
                {uploading && (
                  <div className="bg-blue-50 text-blue-700 px-4 py-3 rounded-2xl text-sm font-medium">
                    Mengupload foto profile...
                  </div>
                )}
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-[#DFF6F3] flex items-center justify-center text-[#004D4D]">
                    <User size={22} />
                  </div>

                  <div>
                    <p className="text-sm text-slate-500">
                      Username
                    </p>

                    <h3 className="font-semibold text-lg text-slate-800">
                      {user?.username}
                    </h3>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-[#DFF6F3] flex items-center justify-center text-[#004D4D]">
                    <ShieldCheck size={22} />
                  </div>

                  <div>
                    <p className="text-sm text-slate-500">
                      Role
                    </p>

                    <h3 className="font-semibold text-lg text-slate-800 capitalize">
                      {user?.role}
                    </h3>
                  </div>
                </div>
                <div className="flex justify-end">
                  <button
                      onClick={() => {
                        localStorage.removeItem("token")
                        router.push("/login")
                      }}
                      className="bg-[#004D4D] hover:bg-[#006666] text-white px-6 py-3 rounded-2xl font-semibold transition shadow-lg"
                    >
                      Logout
                    </button>
                  </div>
              </div>
            </div>

            <div className="bg-white rounded-md p-8 shadow-sm border border-slate-100">
              <h2 className="text-2xl font-bold mb-6 text-slate-800">
                Aktivitas
              </h2>

              <div className="space-y-5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <FileText size={18} />
                    <span>Total Thread</span>
                  </div>

                  <span className="font-bold">
                    {totalReports}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Clock3 size={18} />
                    <span>Diproses</span>
                  </div>

                  <span className="font-bold text-yellow-600">
                    {processedReports}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <CheckCircle2 size={18} />
                    <span>Selesai</span>
                  </div>

                  <span className="font-bold text-green-600">
                    {completedReports}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT */}
          <div className="col-span-2 bg-white rounded-md p-8 shadow-sm border border-slate-100">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h2 className="text-3xl font-bold text-slate-800">
                  Thread Laporan Saya
                </h2>

                <p className="text-slate-500 mt-2">
                  Riwayat laporan yang telah Anda buat
                </p>
              </div>
            </div>

            <div className="space-y-6">
              {reports.length === 0 ? (
                <div className="text-center py-20">
                  <div className="text-7xl mb-5">
                    📭
                  </div>

                  <h3 className="text-2xl font-bold text-slate-700">
                    Belum Ada Laporan
                  </h3>

                  <p className="text-slate-500 mt-3">
                    Anda belum membuat laporan apapun.
                  </p>
                </div>
              ) : (
                reports.map((report) => (
                  <div
                    key={report.id}
                    className="border border-slate-100 rounded-3xl overflow-hidden hover:shadow-lg transition"
                  >
                    {report.image && (
                      <img
                        src={`http://localhost:4000/uploads/${report.image}`}
                        alt={report.header}
                        className="w-full h-[280px] object-cover"
                      />
                    )}

                    <div className="p-6">
                      <div className="flex items-start justify-between gap-5">
                        <div>
                          <h2 className="text-2xl font-bold text-slate-800">
                            {report.header}
                          </h2>

                          <div className="flex items-center gap-2 mt-3 text-slate-500 text-sm">
                            <MapPin size={15} />
                            {report.location}
                          </div>
                        </div>

                        <span className="bg-[#DFF6F3] text-[#004D4D] px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap">
                          {report.status || "Menunggu"}
                        </span>
                      </div>

                      <p className="text-slate-600 leading-relaxed mt-5">
                        {report.body}
                      </p>

                      <div className="mt-6 flex items-center justify-between">
                        <span className="text-sm text-slate-500">
                          {new Date(
                            report.created_at
                          ).toLocaleDateString("id-ID")}
                        </span>

                        <button 
                          onClick={() => router.push(`/user/report/${report.id}`)}
                          className="bg-[#004D4D] hover:bg-[#006666] text-white px-5 py-3 rounded-2xl transition font-medium"
                        >
                          Lihat Detail
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
